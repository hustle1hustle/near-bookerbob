# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.0](https://github.com/near/near-sdk-rs/compare/near-sys-v0.3.0...near-sys-v0.4.0) - 2026-10-27

### Fixed

- *(near-sys)* [**breaking**] declare host functions extern "C-unwind" ([#1656](https://github.com/near/near-sdk-rs/pull/1656))

## [0.3.0](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.14...near-sys-v0.3.0) - 2026-10-19

### Added

- [**breaking**] forward raw state init bytes and validate canonical UAIDs (NEP-655) ([#1642](https://github.com/near/near-sdk-rs/pull/1642))
- *(near-sys)* add ml_dsa_verify, sha3, and universal state init bindings (nearcore 2.14) ([#1628](https://github.com/near/near-sdk-rs/pull/1628))

## [0.2.14](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.13...near-sys-v0.2.14) - 2026-08-27

### Other

- enable all features on docs.rs for near-sdk and near-sys

## [0.2.13](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.12...near-sys-v0.2.13) - 2026-07-13

### Added

- *(env)* add env::chain_id host-fn wrapper ([#1592](https://github.com/near/near-sdk-rs/pull/1592))

## [0.2.12](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.11...near-sys-v0.2.12) - 2026-07-08

### Added

- add `p256_verify` ([#1577](https://github.com/near/near-sdk-rs/pull/1577))

## [0.2.11](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.10...near-sys-v0.2.11) - 2026-07-01

### Added

- add gas-key host functions (nearcore 2.13) ([#1568](https://github.com/near/near-sdk-rs/pull/1568))

## [0.2.10](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.9...near-sys-v0.2.10) - 2026-06-09

### Fixed

- *(near-sys)* declare host function imports from the "env" wasm module ([#1550](https://github.com/near/near-sdk-rs/pull/1550))

## [0.2.9](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.8...near-sys-v0.2.9) - 2026-04-07

### Other

- release ([#1525](https://github.com/near/near-sdk-rs/pull/1525))

## [0.2.8](https://github.com/near/near-sdk-rs/releases/tag/near-sys-v0.2.8) - 2026-03-26

### Other

- release ([#1520](https://github.com/near/near-sdk-rs/pull/1520))
- remove `global-contracts` feature gates ([#1507](https://github.com/near/near-sdk-rs/pull/1507))
- update to Rust edition 2024 ([#1480](https://github.com/near/near-sdk-rs/pull/1480))

## [0.2.8](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.7...near-sys-v0.2.8) - 2026-03-26

### Other

- remove `global-contracts` feature gates ([#1507](https://github.com/near/near-sdk-rs/pull/1507))
- update to Rust edition 2024 ([#1480](https://github.com/near/near-sdk-rs/pull/1480))

## [0.2.7](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.6...near-sys-v0.2.7) - 2026-02-05

### Other

- enabling msrv in workspace crates via Cargo.toml ([#1467](https://github.com/near/near-sdk-rs/pull/1467))

## [0.2.6](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.5...near-sys-v0.2.6) - 2025-12-01

### Added

- Added support for refund_to and current_contract_code, updated deps to match nearcore 2.10 release ([#1423](https://github.com/near/near-sdk-rs/pull/1423))

## [0.2.4](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.3...near-sys-v0.2.4) - 2025-05-14

### Other

- updates near-* dependencies to 0.30 release ([#1356](https://github.com/near/near-sdk-rs/pull/1356))

## [0.2.3](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.2...near-sys-v0.2.3) - 2025-05-05

### Added

- Added BLS12-381 curve operations support in near-sys and exposed in near_sdk::env ([#1346](https://github.com/near/near-sdk-rs/pull/1346))

## [0.2.2](https://github.com/near/near-sdk-rs/compare/near-sys-v0.2.1...near-sys-v0.2.2) - 2024-07-04

### Other
- add yield execution host functions ([#1183](https://github.com/near/near-sdk-rs/pull/1183))

## [0.2.1](https://github.com/near/near-sdk-rs/compare/4.1.1...near-sys-v0.2.1) - 2023-11-18

### Other
- Add release-plz to automate releases ([#1069](https://github.com/near/near-sdk-rs/pull/1069))
